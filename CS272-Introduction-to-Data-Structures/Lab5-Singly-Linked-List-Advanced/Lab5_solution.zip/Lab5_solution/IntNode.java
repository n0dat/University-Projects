
public class IntNode {
	private int value;
	private IntNode next;
		
	public IntNode(){
		value = 0;
		next = null;
	}//end of default constructor
		
	public IntNode(int data, IntNode node){
		value = data;
		next = node;
	}
	
	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public IntNode getNext() {
		return next;
	}

	public void setNext(IntNode next) {
		this.next = next;
	}
	
	public void addNodeAfterThis(int newdata) {
	        IntNode newNode = new IntNode(newdata, this.getNext());
	        this.setNext(newNode);
	 }
	
	public static boolean hasCycle(IntNode head) {
	IntNode current= head;

	while(current != null && current != head)
		current = current.next;
	
	return(current == head);
}
	
	public static void changeElement(IntNode head, int i, int newValue) {
		IntNode current = head;
		for(int index = 0; index < i; index++) {
			current = current.next;
		}
		current.setValue(newValue);
	}
	
	public static void segregate_even_odd(IntNode head) {
	IntNode cursor;
	IntNode nodeEven = new IntNode();
	//IntNode nodeOdd = new IntNode();
	//boolean firstEvenHead = false;


	for(cursor = head; cursor != null; cursor = cursor.next) {
		if(cursor.value % 2 == 0)
			nodeEven.addNodeAfterThis(cursor.value);
	}
	for(cursor = head; cursor != null; cursor = cursor.next) {
		if(cursor.value % 2 != 0)
			nodeEven.addNodeAfterThis(cursor.value);
}
	
	}
	   public static IntNode reverse(IntNode head) {

			  IntNode previous = null;
		      IntNode current = head;
		      IntNode next = null;
		       
		      while (current != null) {
		         next = current.next;
		         current.setNext(previous);
		         previous = current;
		         current = next;
		      } 
		      return previous;
		   } 
	   
	   public void swap() {
		      
	  	   IntNode current = this;
	  	   
		   while(current.next != null) {
		      current = current.next;
		   }
		      int last = current.value;
			  current.setValue(this.getValue());
			  this.setValue(last); 
	   }  
}



