public class IntNode {
    private int data;
    private IntNode link;

    public int getData() {
        return this.data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public IntNode getLink() {
        return this.link;
    }

    public void setLink(IntNode link) {
        this.link = link;
    }

    public IntNode() {
        this.data = 0;
        this.link = null;
    }

    public IntNode(int data, IntNode link) {
        this.data = data;
        this.link = link;
    }

    public String toString() {
        String s = String.format("%d", this.data);
        IntNode node = this.link;
        while (node != null) {
            s += String.format("->%d", node.data);
            node = node.getLink();
        }
        return s;
    }

    public void addNodeAfterThis(int newdata) {
        IntNode newNode = new IntNode(newdata, this.getLink());
        this.setLink(newNode);
    }

    public void removeNodeAfterThis() {
        IntNode node = this.getLink();
        if (node != null)
            this.setLink(node.getLink());
    }

    public static int listLength(IntNode head) {
        if (head == null) {
            return 0;
        }
        else {
            int len = 1;
            IntNode h = head.getLink();
            while (h != null) {
                len++;
                h = h.getLink();
            }
            return len;
        }
    }

    public static boolean search(IntNode head, int data) {
        IntNode h = head;
        while (h != null) {
            if (h.getData() == data) return true;
            h = h.getLink();
        }
        return false;
    }

    public static IntNode findMthToLast(IntNode header, int m) {
        IntNode current, mBehind;
        current = header;
        for (int i = 0; i < m; i++) {
            if (current.link != null) {
                current = current.link;
            } else {
                return null;
            }
        }
        mBehind = header;
        while (current.link != null) {
            current = current.link;
            mBehind = mBehind.link;
        }
        return mBehind;
    }
}