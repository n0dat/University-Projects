public class IntNodeTest {
    public static void main(String[] args) {
        IntNode a = new IntNode(5, null);
        IntNode b = new IntNode(6, a);
        IntNode c = new IntNode(9, b);
        System.out.println(b);
        System.out.println(c);
        b.addNodeAfterThis(10);
        System.out.println(c.toString());
        System.out.println(IntNode.listLength(c));
        b.removeNodeAfterThis();
        System.out.println(c.toString());
        a.removeNodeAfterThis();
        System.out.println(c.toString());
        System.out.println(IntNode.listLength(c));
        System.out.println(IntNode.search(c, 5));
        System.out.println(IntNode.search(c, 100));
        System.out.println(IntNode.search(null, 5));
        System.out.println(IntNode.findMthToLast(c, 2));
        System.out.println(IntNode.findMthToLast(c, 0));
        System.out.println(IntNode.findMthToLast(c, -1));
        System.out.println(IntNode.findMthToLast(c, 3));
        System.out.println(IntNode.findMthToLast(b, 2));
    }
}