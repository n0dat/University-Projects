import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EmployeeSet {
	private Employee[] emplArray;
	private int numEmp;

	/**
	 * Initialize an empty Employee set with an initial capacity of 10. Note that
	 * the add method works efficiently (without needing more memory) until this
	 * capacity is reached.
	 * 
	 * @postcondition This bag is empty and has an initial capacity of 10.
	 * @exception OutOfMemoryError
	 *                Indicates insufficient memory for: new Object[10].
	 **/
	public EmployeeSet() {
		final int INITIAL_CAPACITY = 10;
		this.numEmp = 0;
		this.emplArray = new Employee[INITIAL_CAPACITY];
	}

	/**
	 * Initialize an Employee set by copying the argument obj.
	 **/
	public EmployeeSet(Object obj) {

		if ((obj != null) && (obj instanceof EmployeeSet)) {
			EmployeeSet empSet = (EmployeeSet) obj;
			this.numEmp = empSet.numEmp;
			this.emplArray = new Employee[this.numEmp];
			for (int i = 0; i < empSet.numEmp; i++) {
				this.emplArray[i] = (Employee) empSet.emplArray[i].clone();
			}
		} // end if

	}

	/**
	 * Returns the number of Employee objects in the set.
	 * 
	 * @return the number of Employee objects in the set.
	 **/
	public int size() {
		return this.numEmp;
	}

	/**
	 * Returns the capacity of the set.
	 * 
	 * @return the capacity of the set.
	 **/
	public int capacity() {
		return this.emplArray.length;
	}

	/**
	 * Guarantees the capacity of the collection. If this collection's capacity is
	 * smaller than the input parameter, this method sets the capacity to
	 * minimumCapacity and enlarges the array to hold minimumCapacity objects;
	 * Otherwise, this collection is left unchanged.
	 * 
	 * @precondition the input parameter minimumCapacity is positive
	 **/
	private void ensureCapacity(int minimumCapacity) {
		Employee biggerArr[];

		if (this.emplArray.length < minimumCapacity) {
			biggerArr = new Employee[minimumCapacity];
			for (int i = 0; i < this.emplArray.length; i++) {
				biggerArr[i] = this.emplArray[i];
			}
			this.emplArray = biggerArr;
		}

	} // end ensureCapacity

	/**
	 * Adds one given Employee object to the first available space of the employee
	 * array in this EmployeeSet instance. When the collection space is sufficient
	 * to hold the new employee, this employee object can be directly added to the
	 * collection. Otherwise, the method will double the space of the instance
	 * array.
	 * 
	 * @precondition the employee object is not null.
	 **/
	public void add(Employee a) {
//		System.out.println("capacity: "  + emplArray.length);
		if (a != null) {
			for(int i=0;i<numEmp;i++) {
				if(emplArray[i].getNo()==a.getNo()){
					return;
				}
			}
			if (numEmp == emplArray.length)
				ensureCapacity((numEmp + 1) * 2);

			this.emplArray[numEmp] = a;
			numEmp++;
		}
	}

	/**
	 * check whether the collection contains an employee with the given employee no
	 * eno.
	 * 
	 * @return true if the collection contains an employee with the given employee
	 *         no eno.
	 **/

	public boolean contains(int eno) {
		for (int i = 0; i < numEmp; i++)
			if (this.emplArray[i].getNo() == eno)
				return true;
		return false;

	}

	/**
	 * remove from the collection the employee with the given employee no eno.
	 * 
	 **/

	public boolean remove(int eno) {

		int index;

		for (index = 0; (index < numEmp) && (eno != this.emplArray[index].getNo()); index++)
			;
		if (numEmp == index)
			return false;
		else {
			numEmp--;
			Employee[] anotherArray = new Employee[this.emplArray.length - 1];

			// Copy the elements except the index
			// from original array to the other array
			for (int i = 0, k = 0; i < this.emplArray.length; i++) {
				if (i == index) {
					continue;
				}

				anotherArray[k++] = this.emplArray[i];
			}

			this.emplArray = anotherArray;
			return true;
		}

	} // end remove

	public static void main(String[] args) throws IOException {
		EmployeeSet eBag1 = new EmployeeSet();
		
		try (BufferedReader br = new BufferedReader(new FileReader("core_dataset.csv"))) {
			String line;

			while ((line = br.readLine()) != null) {
				String[] values = line.split(",");

				if (values.length > 6) {
					Employee e = new Employee();
					e.setName(values[0] + values[1]);
					e.setNo(Integer.parseInt(values[2]));
					e.setState(values[3]);
					e.setZip(Integer.parseInt(values[4]));
					e.setAge(Integer.parseInt(values[5]));
					e.setAdvisor(values[6]);

					eBag1.add(e);
				}
			}
		}
		
		EmployeeSet eBag2 = new EmployeeSet(eBag1);
		
		System.out.println("Num of employee: " + eBag1.size());
		System.out.println("Capacity: " + eBag1.capacity());
		System.out.println("eBag1 Contains 711007713? " + eBag1.contains(711007713));
		System.out.println("Remove 711007713 in eBag1");
		eBag1.remove(711007713);
		System.out.println("eBag1 Contains 711007713? " + eBag1.contains(711007713));

		System.out.println("eBag2 Contains 711007713? "+ eBag2.contains(711007713));
	}

}
