import java.util.Arrays;

public class Employee implements Cloneable {

	// Initializes instance variables.
	private String name;
	private int no;
	private int age;
	private String state;
	private int zip;
	String advisor;
	private Integer[] advisors;

	/**
	 * Initialize an Employee object.
	 * 
	 * @postcondition name=null, state=null, no=0, age=0, zip=0, advisors has size
	 *                3.
	 **/
	public Employee() {

		name = null;
		no = 0;
		age = 0;
		state = null;
		zip = 0;
		advisors = new Integer[3];

	} // end constructor

	/**
	 * Initialize an Employee object by copying the argument obj.
	 **/
	public Employee(Object obj) {

		// Checks for precondition
		if ((obj != null) && (obj instanceof Employee)) {

			// Copies all variable of obj
			// to the new object called emp.
			Employee emp = (Employee) obj;
			name = new String(emp.name);
			no = emp.no;
			age = emp.age;
			state = new String(emp.state);
			zip = emp.zip;
			advisors = new Integer[3];
			for (int i = 0; i < emp.advisors.length; i++) {
				if (emp.advisors[i] != null) {
					advisors[i] = Integer.valueOf(emp.advisors[i]);
				}
			}

		} // end if

	} // end copy constructor

	/**
	 * Creates and returns a deep copy of this Employee object.
	 * 
	 * @return a clone of this Employee instance.
	 **/
	public Object clone() {

		Employee answer;
		try {

			// Creates clone and then copies all variables to clone.
			answer = (Employee) super.clone();
			answer.name = new String(name);
			answer.no = no;
			answer.age = age;
			answer.state = new String(state);
			answer.zip = zip;
			answer.advisors = new Integer[3];
			for (int i = 0; i < advisors.length; i++) {
				if (advisors[i] != null) {
					answer.advisors[i] = Integer.valueOf(advisors[i]);
				}
			}
		} // end try

		// Catches an exception if necessary.
		catch (CloneNotSupportedException e) {

			// Throws RuntimeException and prints a message.
			System.out.println(e.getMessage());
			throw new RuntimeException("This class does not implement Cloneable.");

		} // end catch

		// Returns new clone.
		return answer;

	} // end clone

	/**
	 * Returns the name of this Employee object.
	 * 
	 * @return the name of this Employee object.
	 **/
	public String getName() {
		return name;
	}

	/**
	 * Set the name of this Employee object.
	 **/
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the number of this Employee object.
	 * 
	 * @return the number of this Employee object.
	 **/
	public int getNo() {
		return no;
	}

	/**
	 * Set the number of this Employee object.
	 **/
	public void setNo(int no) {
		this.no = no;
	}

	/**
	 * Returns the age of this Employee object.
	 * 
	 * @return the age of this Employee object.
	 **/
	public int getAge() {
		return age;
	}

	/**
	 * Set the age of this Employee object.
	 **/
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * Returns the state of this Employee object.
	 * 
	 * @return the state of this Employee object.
	 **/
	public String getState() {
		return state;
	}

	/**
	 * Set the state of this Employee object.
	 **/
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Returns the zip code of this Employee object.
	 * 
	 * @return the zip code of this Employee object.
	 **/
	public int getZip() {
		return zip;
	}

	/**
	 * Set the zip code of this Employee object.
	 **/
	public void setZip(int zip) {
		this.zip = zip;
	}

	/**
	 * Returns the advisors of this Employee object.
	 * 
	 * @return a copy of the advisors.
	 **/
	public Integer[] getAdvisor() {
		Integer[] answer = new Integer[3];
		for (int i = 0; i < advisors.length; i++) {
			if (advisors[i] != null) {
				answer[i] = Integer.valueOf(advisors[i]);
			}
		}
		return answer;
	}

	/**
	 * Set the advisors of this Employee object. Input will be copied.
	 **/
	public void setAdvisors(Integer[] input) {
		if (input == null)
			throw new IllegalArgumentException("Input must not be null.");
		advisors = new Integer[3];
		for (int i = 0; i < input.length; i++) {
			if (input[i] != null) {
				advisors[i] = Integer.valueOf(input[i]);
			}
		}
	}

	/**
	 * Returns a string representation of this Employee object.
	 * 
	 * @return a string representation of this Employee object.
	 **/

	public String toString() {

		// Returns the employee info with the string
		// from the advisors array.
		String s = "";
		if (advisors[0] != null) {
			s += advisors[0];
		}
		for (int i = 1; i < advisors.length; i++) {
			if (advisors[i] != null) {
				s += ", " + advisors[i];
			}
		}
		return "Name: " + name + "\nEmployee #: " + no + "\nAge: " + age + "\nState: " + state + "\nZipcode: " + zip
				+ "\nAdvisors: " + s + "\n";

	} // end toString

	/**
	 * Returns true if the given object's employee no is the same as the no of this
	 * Employee object.
	 * 
	 * @return true if the two Employee objects are equal.
	 **/
	public boolean equals(Object obj) {
		// Checks obj for precondition.
		if ((obj != null) && (obj instanceof Employee)) {

			// Returns true if variables match.
			Employee temp = (Employee) obj;
			return temp.no == no;

		} // end if

		// Returns false if they don't match.
		return false;

	} // end equals

	/**
	 * A static method to get all the DISTINCT advisors of two employees which are
	 * the input parameters.
	 * 
	 * @return the DISTINCT advisors of two employees.
	 **/

	public static int[] getAllAdvisors(Employee e1, Employee e2) {

		// Checks if e1 and e2 are null.
		if ((e1 == null) || (e2 == null))
			throw new IllegalArgumentException("Two parameters must not be null.");
		Integer[] answer = new Integer[e1.advisors.length + e2.advisors.length];
		int count = 0;
		for (int i = 0; i < e1.advisors.length; i++) {
			if (e1.advisors[i] != null) {
				answer[i] = e1.advisors[i];
				count++;
			}
		}
		for (int i = 0; i < e2.advisors.length; i++) {
			boolean distinct = true;
			if (e2.advisors[i] != null) {
				for (int j = 0; j < e1.advisors.length; j++) {
					if (e1.advisors[j] == e2.advisors[i]) {
						distinct = false;
					}
				}
			}
			if (distinct) {
				answer[count++] = e2.advisors[i];
			}
		}
		int[] ret = new int[count - 1];
		for (int i = 0; i < ret.length; i++) {
			ret[i] = answer[i].intValue();
		}
		return ret;
	} // end getAllAdvisors

	public void setAdvisor(String string) {
		advisor = string;
	}
} // end class